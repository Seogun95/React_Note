import { legacy_createStore } from "redux";

const ADD = "ADD";
const DELETE = "DELETE";
const MOVEDON = "MOVEDON";

export const addToDo = (text, body) => {
  return {
    type: ADD,
    text,
    body,
  };
};

export const deleteToDo = (id) => {
  return {
    type: DELETE,
    id: parseInt(id),
  };
};

export const moveToDo = (id, isDon) => {
  return {
    type: MOVEDON,
    id: parseInt(id),
    isDon,
  };
};

const reducer = (state = [], action) => {
  switch (action.type) {
    case ADD:
      return [
        { text: action.text, body: action.body, id: Date.now(), isDon: false },
        ...state,
      ];
    case DELETE:
      return state.filter((toDo) => toDo.id !== action.id);
    case MOVEDON:
      return state.map((toDo) => {
        if (toDo.id === action.id) {
          return { ...toDo, isDon: action.isDon };
        }
        return toDo;
      });
    default:
      return state;
  }
};

export default reducer;
