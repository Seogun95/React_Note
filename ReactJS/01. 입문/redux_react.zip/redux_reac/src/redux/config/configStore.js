import { combineReducers, legacy_createStore } from "redux";
import reducer from "../modules/todo";

const rootReducer = combineReducers({
  reducer,
});

export const store = legacy_createStore(rootReducer); //상태 변경후 store에 저장

export default store;
