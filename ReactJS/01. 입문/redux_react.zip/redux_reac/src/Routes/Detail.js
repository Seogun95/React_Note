import React from "react";
import { useSelector } from "react-redux";
import { Link, useParams } from "react-router-dom";

function Detail() {
  const detailId = useParams().id;
  const todo = useSelector((state) => state.reducer);
  const toDo = todo.find((toDo) => toDo.id === parseInt(detailId));
  return (
    <div>
      <Link to={`/`}>
        <h4>이전으로</h4>
      </Link>
      <h1>Detail</h1>
      <h2>유저 ID: {toDo.id}</h2>
      <h3>제목: {toDo.text}</h3>
      <h3>내용: {toDo.body}</h3>
    </div>
  );
}

export default Detail;
